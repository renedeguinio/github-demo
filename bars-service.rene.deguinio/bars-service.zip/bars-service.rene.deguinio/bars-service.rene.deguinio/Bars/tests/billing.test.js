const test = require('supertest');
const app = require('../index')
//const Billings = require('../models/billing');
// const BillingRequest = require('../router/billing-request');

test('Read CSV Valid Request Parameter', () => {
    fileReader('valid-csv.csv');
    expect(Object).toBe(Object);
});

// BARS TS.002: Test error conditions for readCsv()
test('Read Invalid CSV Request With Invalid Billing Cycle', () => {
    fileReader('billing-cycle-not-on-range-csv.csv');
    expect(Error).toBe(Error);
});

test('Read Invalid CSV Request With Invalid Start Date Format', () => {
    fileReader('invalid-start-date-csv.csv');
    expect(Error).toBe(Error);
});

test('Read Invalid CSV Request With Invalid End Date Format', () => {
    fileReader('invalid-end-date-csv.csv');
    expect(Error).toBe(Error);
});

test('Read an empty CSV file.', () => {
    fileReader('empty-csv.csv');
    expect(Error).toBe(Error);
});

// BARS TS.003: Test normal conditions for readTxt()
test('Read TXT Valid Request Parameter', () => {
    fileReader('valid-txt.txt');
    expect(Object).toBe(Object);
});

// BARS TS.004: Test error conditions for readTxt()
test('Read Invalid TXT Request With Invalid Billing Cycle', () => {
    fileReader('billing-cycle-not-on-range-txt.txt');
    expect(Error).toBe(Error);
});

test('Read Invalid TXT Request With Invalid Start Date Format', () => {
    fileReader('invalid-start-date-txt.txt');
    expect(Error).toBe(Error);
});

test('Read Invalid TXT Request With Invalid End Date Format', () => {
    fileReader('invalid-end-date-txt.txt');
    expect(Error).toBe(Error);
});

test('Read an empty TXT file.', () => {
    fileReader('empty-txt.txt');
    expect(Error).toBe(Error);
});
