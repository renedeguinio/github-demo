const { request } = require('express');
const mongoose = require('mongoose');
const billings = require('../router/billing-request');

const userSchema = new mongoose.Schema({
billingCycle: {
    type: String
},
billingMonth: {
    type: String
},
amount: {
    type: String
},
startDate: {
    type: Date
},
endDate: {
    type: String
},
lastEdited: {
    type: String
},
account: {
    accountName: {
        type: String
    },
    dateCreated: {
        type: String
    },
    isActive: {
        type: String
    },
    lastEdited: {
        type: String
    },
    customer: {
        firstName: {
            type: String
        },
        lastName: {
            type: String
        },
        address: {
            type: String
        },
        status: {
            type: String
        },
        dateCreated: {
            type: String
        },
        lastEdited: {
            type: String
        }
    }
}
})

const Billings = mongoose.model('billings', {
    billingCycle: {
        type: String
    },
    billingMonth: {
        type: String
    },
    amount: {
        type: String
    },
    startDate: {
        type: String
    },
    endDate: {
        type: String
    },
    lastEdited: {
        type: String
    },
    account: {
        accountName: {
            type: String
        },
        dateCreated: {
            type: String
        },
        isActive: {
            type: String
        },
        lastEdited: {
            type: String
        },
        customer: {
            firstName: {
                type: String
            },
            lastName: {
                type: String
            },
            address: {
                type: String
            },
            status: {
                type: String
            },
            dateCreated: {
                type: String
            },
            lastEdited: {
                type: String
            }
        }
    }
});

module.exports = Billings;

