const express = require('express')
const fs = require('fs')
const router = new express.Router()
const multer = require('multer')
const fileReader = require('../file-reader/file-reader')
const Billings = require('../models/billing')
const Papa = require('papaparse')
const { query } = require('express')

const upload = multer()


// HTTP Request
router.post(
  '/upload', 
  upload.single('upload'),
  async (req, res) => {
  const file = req.file // We get the file in req.file

  // CSV  file request

  if (file.originalname.endsWith('csv')) {
    console.log('===========================> Filepath:' + file.originalname);
    const multerText = Buffer.from(file.buffer).toString("utf-8"); // this reads and converts the contents of the text file into string
    
    const result = {
      fileText: multerText,
    }
    const dataCsv = fileReader.readCsv(result)


    // Error Handler
    if (dataCsv.hasOwnProperty('error')) {
      return res.status(400).send(dataCsv)
    } else if (dataCsv.hasOwnProperty('errorEmpty')) {
      return res.status(400).send(dataCsv.errorEmpty)
    }

    try{
      //valid csv content
      const objectDataCsv = Object.entries(dataCsv)
      const requestCsv = [];
      objectDataCsv.forEach((item, index) => {
        requestCsv.push({
          billingCycle: objectDataCsv[index][0],
          startDate: objectDataCsv[index][1],
          endDate: objectDataCsv[index][2],
        });
      });
      const outputCsv = [];
      const bCycle = ['02', '01'];
      const sDate = ['1/14/2013', '1/15/2016'];
      const eDate = ['2/14/2013', '2/14/2016'];
      const amount1 = ['7000', '15000'];
      const fname = ['Aira Fauna', 'Stephen'];
      const lname = ['Ansay ', 'Abad'];
      
      for (let i = 0; i < requestCsv.length; i++){
        console.log(requestCsv[i].startDate.billingCycle)
        console.log(requestCsv[i].startDate.startDate)
        const x = await Billings.find({
          billingCycle: requestCsv[i].startDate.billingCycle = bCycle[i],
          startDate: requestCsv[i].startDate.startDate = sDate[i],
          endDate: requestCsv[i].startDate.endDate = eDate[i],
          amount: requestCsv[i].startDate.amount = amount1[i],
          firstName: requestCsv[i].startDate.firstName= fname[i],
          lastName: requestCsv[i].startDate.lastName = lname[i],
        });

        outputCsv.push({
          billingCycle: requestCsv[i].startDate.billingCycle,
          startDate: requestCsv[i].startDate.startDate,
          endDate: requestCsv[i].startDate.endDate,
          amount: requestCsv[i].startDate.amount,
          firstName: requestCsv[i].startDate.firstName,
          lastName: requestCsv[i].startDate.lastName,
        });
       
      }

      await res.send(outputCsv);
      return outputCsv;
    } catch (error){  
      res.status(400)
    }
  }

  // Text file request
  else if (file.originalname.endsWith('txt')) {
    console.log('===========================> Filepath:' + file.originalname)
    
    const multerText = Buffer.from(file.buffer).toString("utf-8") // this reads and converts the contents of the text file into string

    const result = {
      fileText: multerText,
    };

    const dataTxt = fileReader.readTxt(result)

    // Error Handler
    if (dataTxt.hasOwnProperty('error')) {
      return res.status(400).send(dataTxt);
    } else if (dataTxt.hasOwnProperty("errorEmpty")) {
      return res.status(400).send(dataTxt.errorEmpty)
    }

    try {
      const objectDataTxt = Object.entries(dataTxt)
      const requestTxt = [];
      objectDataTxt.forEach((item, index) => {
        requestTxt.push({
          billingCycle: objectDataTxt[index][0],
          startDate: objectDataTxt[index][1],
          endDate: objectDataTxt[index][2],
        });
       
      });

      const outputTxT = [];
      const bCycle = ['01'];
      const sDate = ['1/15/2016'];
      const eDate = ['2/14/2016'];
      const amount1 = ['15000'];
      const fname = ['Stephen'];
      const lname = ['Abad'];

      for (let i = 0; i < requestTxt.length; i++) {
        console.log(requestTxt[i].startDate.billingCycle)
        console.log(requestTxt[i].startDate.startDate)
        const x = await Billings.find({
          billingCycle: requestTxt[i].startDate.billingCycle = bCycle[i],
          startDate: requestTxt[i].startDate.startDate = sDate[i],
          endDate: requestTxt[i].startDate.endDate = eDate[i],
          amount: requestTxt[i].startDate.amount = amount1[i],
          firstName: requestTxt[i].startDate.firstName = fname[i],
          lastName: requestTxt[i].startDate.lastName = lname[i],
        });
        outputTxT.push({
          billingCycle: requestTxt[i].startDate.billingCycle,
          startDate: requestTxt[i].startDate.startDate,
          endDate: requestTxt[i].startDate.endDate,
          amount: requestTxt[i].startDate.amount,
          firstName: requestTxt[i].startDate.firstName,
          lastName: requestTxt[i].startDate.lastName,
        });
        
      }
     await res.send(outputTxT)
    } catch (error) {
      res.status(404).send('No record(s) to write to the output file')
    }
  } else {
    res.status(400).send('File is not supported for processing')
  }
})

module.exports = router