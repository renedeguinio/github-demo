const readTxt = function (obj) {
    console.log('==> INSIDE TXT PROCESSING<==')
    const request = []
  
    // Error Handler for empty file
    if (obj.fileText.length === 0) {
      const error = { errorEmpty: 'No request(s) to read from the input file.' }
  
      return error
    }
  
    const getResult = obj.fileText.split("\r\n")
  
    // Counter for row
    let counter = 0
  
    for (const x of getResult) {
      getContent = x
      counter = counter + 1
  
      billing = {
        billingCycle: Number,
        startDate: Date,
        endDate: Date,
      };
  
      const startYear = getContent.slice(6, 10)
      const startDay = getContent.slice(4, 6)
      const startMonth = getContent.slice(2, 4)
  
      const endYear = getContent.slice(14, 18)
      const endDay = getContent.slice(12, 14)
      const endMonth = getContent.slice(10, 12)
  
      // Error handler in invalid date
      if (startDay === "  " || startMonth === "  " || startDay === "   ") {
        const error = { error: "Invalid Start Date format at row  " + counter }
        return error;
      } else if (endDay === "  " || endMonth === "  " || endDay === "   ") {
        const error = { error: "Invalid End Date format at row  " + counter }
        return error;
      }
  
      const startDateToConvert = startYear + "-" + startMonth + "-" + startDay
      const endDateToConvert = endYear + "-" + endMonth + "-" + endDay
  
      const stringStartDate = startDateToConvert.toString()
      const stringEndDate = endDateToConvert.toString()
  
      const convertedStartDate = new Date(stringStartDate)
      const convertedEndDate = new Date(stringEndDate)
  
      const billCycle = Number(getContent.slice(0, 2))
  
      // Error Handlers
  
      if (billCycle >= 13) {
        const error = { error: "Data not in range at " + counter }
        return error;
      }
      billing.billingCycle = billCycle
      billing.startDate = convertedStartDate
      billing.endDate = convertedEndDate
  
      request.push(billing)
    }
    console.log("==> Processing Request with 3 parameters")
    return request
  }
  
  const readCsv = function (obj) {
    console.log("==> INSIDE CSV PROCESSING <==")
    const request = []
  
    // Error Handler for empty file
    if (obj.fileText.length === 0) {
      const error = { errorEmpty: "No request(s) to read from the input file." }
  
      return error
    }
  
    const getResult = obj.fileText.replace(/[/,]/g, "").split("\r\n")
  
    // Counter for row
    let counter = 0
  
    for (const x of getResult) {
      const getContent = x
      counter = counter + 1
  
      // Error handler in invalid date
      if (/\s/g.test(getContent)) {
        const error = { error: "Invalid Start Date format at row  " + counter }
        return error
      } else if (getContent.length === 15) {
        const error = { error: "Invalid End Date format at row  " + counter }
        return error
      }
  
      const billing = {
        billingCycle: Number,
        startDate: Date,
        endDate: Date,
      };
  
      //
      const startYear = getContent.slice(6, 10)
      const startDay = getContent.slice(4, 6)
      const startMonth = getContent.slice(2, 4)
  
      const endYear = getContent.slice(14, 18)
      const endDay = getContent.slice(12, 14)
      const endMonth = getContent.slice(10, 12)
  
      const startDateToConvert = startYear + "-" + startMonth + "-" + startDay
      const endDateToConvert = endYear + "-" + endMonth + "-" + endDay
  
      const stringStartDate = startDateToConvert.toString()
      const stringEndDate = endDateToConvert.toString()
  
      const convertedStartDate = new Date(stringStartDate)
      const convertedEndDate = new Date(stringEndDate)
      const billCycle = Number(getContent.slice(0, 2)) 
  
      // Error Handlers
  
      if (billCycle >= 13) {
        const error = { error: "Billing cyle not on range at row " + counter }
        return error
      }
      billing.billingCycle = billCycle
      billing.startDate = convertedStartDate
      billing.endDate = convertedEndDate

    //  else if ()
  
      request.push(billing)
    }
    console.log("==> Processing Request with 3 parameters")
    return request
  }


  module.exports = {
    readTxt,
    readCsv,
  }